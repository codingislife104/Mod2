package com.cg.tcc.ui;

/*************************************************************************************************************************************
 * File: ClinicApp.java
 * Version: 1.0
 * Author: Shivangi
 * Description: to add and list patients in TakeCare CLinic
 * Last Modified Date: 26-Oct-2017
 * Change Description: Description about the changes implemented
 *************************************************************************************************************************************/
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.cg.tcc.dto.Patient;
import com.cg.tcc.exception.ClinicException;
import com.cg.tcc.service.IPatientService;
import com.cg.tcc.service.PatientServiceImpl;

public class ClinicApp {
	static IPatientService service;
	static Scanner scan;

	public static void main(String[] args) {
		PropertyConfigurator.configure("res/log4j.properties");
		try {
			service = new PatientServiceImpl();
			System.out.println("Service Started!");
		} catch (ClinicException exp) {
			System.err.println(exp.getMessage());
			System.exit(0);
		}

		UserMenu choice = null;
		scan = new Scanner(System.in);

		while (choice != UserMenu.EXIT) {

			System.out.println("********* TakeCare Clinic Patients **********");
			System.out.println("CHOICE\t MENU");
			System.out.println("==========================");
			for (UserMenu menuItem : UserMenu.values()) {
				System.out.println(menuItem.ordinal() + "\t" + menuItem.name());
			}

			System.out.println("Enter Choice: ");
			int ordinal = scan.nextInt();

			if (ordinal < 0 || ordinal > UserMenu.EXIT.ordinal()) {
				System.err.println("Invalid Choice...");
				continue;
			}

			choice = UserMenu.values()[ordinal];

			switch (choice) {
			case ADD:
				doAdd();
				break;
			case LIST:
				doList();
				break;
			case EXIT:
				System.out.println("Thank You!");
				break;
			}
		}
		scan.close();
	}
	/*Adding values to table*/
	public static void doAdd() {
		Patient Patient = new Patient();

		System.out.println("Enter Patient: ");
		Patient.setPatientName(scan.next());
		System.out.println("Enter age : ");
		Patient.setAge(scan.nextInt());
		System.out.println("Enter phone number: ");
		Patient.setPhone(scan.next());

		System.out.println("Enter description : ");
		Patient.setDescription(scan.next());

		try {
			int c = service.add(Patient);

			if (c > -1)
				System.out.println("Patient successfully added!" + c
						+ " ADDED ");
			else
				System.out.println("Patient could not be added!");
		} catch (ClinicException exp) {
			System.err.println(exp.getMessage());
		}
	}
	/*Listing values from table*/
	public static void doList() {
		System.out.print("Enter Patient Id: ");
		int pt = scan.nextInt();

		try {

			List<Patient> pt_list = service.getAllById(pt);
			if (pt_list == null || pt_list.size() == 0) {
				System.out.println("There is no patient with this ID");
			} else {
				for (Patient Patient : pt_list) {
					System.out.println(Patient);
				}
			}
		} catch (ClinicException exp) {
			System.err.println(exp.getMessage());
		}
	}
}
