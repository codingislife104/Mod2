package com.cg.tcc.service;

/*************************************************************************************************************************************
 * File: PatientServiceImpl.java
 * Version: 1.0
 * Author: Shivangi
 * Description: to add and list patients in TakeCare CLinic
 * Last Modified Date: 26-Oct-2017
 * Change Description: Description about the changes implemented
 *************************************************************************************************************************************/
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.tcc.dao.IPatientDao;
import com.cg.tcc.dao.PatientDaoImpl;
import com.cg.tcc.dto.Patient;
import com.cg.tcc.exception.ClinicException;

public class PatientServiceImpl implements IPatientService {

	private IPatientDao dao = null;

	private List<String> validationErrors;

	public PatientServiceImpl() throws ClinicException {
		dao = new PatientDaoImpl();
	}
	/* Using pattern matcher to validate name*/
	public boolean isValidName(String name) {
		Pattern namePattern = Pattern.compile("[A-Z]{1}[a-zA-Z\\s]{3,25}");
		Matcher nameMatcher = namePattern.matcher(name);
		return nameMatcher.matches();
	}
	/* Using pattern matcher to validate phone*/
	public boolean isValidPhone(String phone) {
		Pattern mobilePattern = Pattern.compile("[1-9]{1}[0-9]{9}");
		Matcher mobileMatcher = mobilePattern.matcher(phone);
		return mobileMatcher.matches();
	}
	/*Validating the values before adding them to a function*/
	public boolean isValidPatient(Patient pt) {
		validationErrors = new ArrayList<>();
		if (pt != null) {
			if (!isValidName((pt.getPatientName()))) {
				validationErrors
						.add("Firt name must start with capital and should be between 4 to 26 chars");
			}
			if (!isValidPhone((pt.getPhone()))) {
				validationErrors.add("Mobile Number is only 10 digits");
			}
		}

		return validationErrors.size() == 0 ? true : false;
	}
	/*Function to add Patients*/
	public int add(Patient pt) throws ClinicException {
		int result = -1;
		if (isValidPatient(pt)) {
			result = dao.add(pt);
		} else {
			throw new ClinicException("Can't have Invalid Patient!"
					+ validationErrors);
		}
		return result;
	}
	/*Function to find Patients by their id*/
	public List<Patient> getAllById(int pt) throws ClinicException {
		return dao.getAllById(pt);
	}
}
