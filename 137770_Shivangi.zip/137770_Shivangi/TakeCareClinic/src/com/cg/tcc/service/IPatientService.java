package com.cg.tcc.service;

/*************************************************************************************************************************************
 * File: IPatientService.java
 * Version: 1.0
 * Author: Shivangi
 * Description: to add and list patients in TakeCare CLinic
 * Last Modified Date: 26-Oct-2017
 * Change Description: Description about the changes implemented
 *************************************************************************************************************************************/
import java.util.List;

import com.cg.tcc.dto.Patient;
import com.cg.tcc.exception.ClinicException;

public interface IPatientService {

	public int add(Patient patient) throws ClinicException;

	public List<Patient> getAllById(int pt) throws ClinicException;

}
