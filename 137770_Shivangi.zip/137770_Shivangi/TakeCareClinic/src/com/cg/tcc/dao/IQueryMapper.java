package com.cg.tcc.dao;

/*************************************************************************************************************************************
 * File: IQueryMapper.java
 * Version: 1.0
 * Author: Shivangi
 * Description: to add and list patients in TakeCare CLinic
 * Last Modified Date: 26-Oct-2017 
 * Change Description: Description about the changes implemented
 *************************************************************************************************************************************/
public interface IQueryMapper {

	public static final String INSERT_PATIENT_QRY = "INSERT INTO patient(patient_id,patient_name,age,phone,description,consultation_date)VALUES(patient_id_Seq.nextval,?,?,?,?,?)";

	public static final String SELECT_PATIENT_BY_ID_QRY = "SELECT * FROM patient WHERE patient_id=?";

	public static final String GET_PID_QRY = "SELECT patient_Id_Seq.currVal from dual";
}
