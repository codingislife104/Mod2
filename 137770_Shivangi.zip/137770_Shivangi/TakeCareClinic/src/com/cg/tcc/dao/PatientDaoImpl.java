package com.cg.tcc.dao;
/*************************************************************************************************************************************
 * File: PatientDaoImpl.java
 * Version: 1.0
 * Author: Shivangi
 * Description: to add and list patients in TakeCare CLinic
 * Last Modified Date: 26-Oct-2017
 * Change Description: Description about the changes implemented
 *************************************************************************************************************************************/
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.tcc.dto.Patient;
import com.cg.tcc.exception.ClinicException;
import com.cg.tcc.util.ConnectionProvider;

public class PatientDaoImpl implements IPatientDao{
	
	private Logger classLogger;
	private ConnectionProvider conPro;

	public PatientDaoImpl() throws ClinicException { /*Constructor for connection*/
		classLogger = Logger.getLogger(PatientDaoImpl.class);
		try {
			conPro = ConnectionProvider.getInstance("res/jdbc.properties");
		} catch (ClassNotFoundException | IOException exp) {
			classLogger.error(exp);
			throw new ClinicException("Data Access Initiation Failed!");
		}
	}

	public Patient mapRow(ResultSet row) throws ClinicException { /*Setting up values*/
		Patient pt = new Patient();
		try {
			pt.setPatientId(row.getInt("patient_id"));
			pt.setPatientName(row.getString("patient_name"));
			pt.setAge(row.getInt("age"));
			pt.setPhone(row.getString("phone"));
			pt.setDescription(row.getString("description"));

		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new ClinicException("Failed to retrieve data!");
		}
		return pt;
	}

	@Override
	public int add(Patient pt) throws ClinicException { /*Function to add Patients to the table*/
		int result = -1;
		LocalDate today=LocalDate.now();
		if (pt != null) {
			try (Connection con = conPro.getConnection();
					PreparedStatement pstInsert = con
							.prepareStatement(IQueryMapper.INSERT_PATIENT_QRY);
					PreparedStatement pstid = con
							.prepareStatement(IQueryMapper.GET_PID_QRY)) {
				classLogger.debug(pt + "being added!");
				pstInsert.setString(1, pt.getPatientName());
				pstInsert.setInt(2, pt.getAge());
				pstInsert.setString(3, pt.getPhone());
				pstInsert.setString(4, pt.getDescription());
				pstInsert.setDate(5, java.sql.Date.valueOf( today ));
				
				classLogger.debug("5 values are added to pst insert");
				int count = pstInsert.executeUpdate();
				if (count > 0) {
					ResultSet rs = pstid.executeQuery();
					if (rs.next())
						result = rs.getInt(1);
				}
			} catch (SQLException exp) {
				classLogger.error(exp);
				throw new ClinicException(
						"Failed to add record!  here is the problem");
			}
		}
		return result;
	}

	@Override
	public List<Patient> getAllById(int pt) throws ClinicException { /*Function to find Patients by their id*/
		List<Patient> patientList = new ArrayList<>();
		try (Connection con = conPro.getConnection();
				PreparedStatement pstSelectAll = con
						.prepareStatement(IQueryMapper.SELECT_PATIENT_BY_ID_QRY)) {

			pstSelectAll.setInt(1,pt);
			ResultSet results = pstSelectAll.executeQuery();
			while (results.next()) {
				patientList.add(mapRow(results));
			}
		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new ClinicException("Failed to retreive record!");
		}
		return patientList;
	}

}
