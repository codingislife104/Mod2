package com.cg.tcc.dto;
/*************************************************************************************************************************************
 * File: Patient.java
 * Version: 1.0
 * Author: Shivangi
 * Description: to add and list patients in TakeCare CLinic
 * Last Modified Date: 26-Oct-2017
 * Change Description: Description about the changes implemented
 *************************************************************************************************************************************/
import java.time.LocalDate;

public class Patient {

	private int patientId;
	private String patientName;
	private int age;
	private String phone;
	private String description;
	private LocalDate consultDate;
	
	public Patient() {
		super();
	}
	
	public Patient(int patientId, String patientName, int age, String phone,
			String description, LocalDate consultDate) {
		super();
		this.patientId = patientId;
		this.patientName = patientName;
		this.age = age;
		this.phone = phone;
		this.description = description;
		this.consultDate = consultDate;
	}
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public LocalDate getConsultDate() {
		return consultDate;
	}
	public void setConsultDate(LocalDate consultDate) {
		this.consultDate = consultDate;
	}
	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + ", patientName="
				+ patientName + ", age=" + age + ", phone=" + phone
				+ ", description=" + description + ", consultDate="
				+ consultDate + "]";
	}
	
	
	
	
}
