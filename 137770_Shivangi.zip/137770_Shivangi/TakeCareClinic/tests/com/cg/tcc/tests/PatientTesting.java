package com.cg.tcc.tests;
/*************************************************************************************************************************************
 * File: PatientTesting.java
 * Version: 1.0
 * Author: Shivangi
 * Description: to add and list patients in TakeCare CLinic
 * Last Modified Date: 26-Oct-2017
 * Change Description: Description about the changes implemented
 *************************************************************************************************************************************/
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.apache.log4j.PropertyConfigurator;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.tcc.dao.IPatientDao;
import com.cg.tcc.dao.PatientDaoImpl;
import com.cg.tcc.dto.Patient;
import com.cg.tcc.exception.ClinicException;

public class PatientTesting {

	IPatientDao dao = null;

	@Before
	public void setUp() throws Exception {
		PropertyConfigurator.configure("res/log4j.properties");
		dao = new PatientDaoImpl();

	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAddNotNullPatient() {
		try {
			Patient input = new Patient();
			input.setPatientName("Umang");
			input.setAge(21);
			input.setPhone("4123265725");
			input.setDescription("AssistantProffesor");

			int notExpected = -1;
			int actual = dao.add(input);
			assertTrue(notExpected != actual);
		} catch (ClinicException exp) {
			fail("Failed to Add new Student Exception " + exp);
		}
	}

	@Test
	public void testAddNullPatient() {
		try {
			Patient input = null;
			int expected = -1;
			int actual = dao.add(input);
			assertTrue(expected == actual);
		} catch (ClinicException exp) {
			fail("This not an expected exception");
		}
	}

}
