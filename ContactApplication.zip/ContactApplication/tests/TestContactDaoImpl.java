

	import static org.junit.Assert.*;

	import org.apache.log4j.PropertyConfigurator;
	import org.junit.After;
	import org.junit.AfterClass;
	import org.junit.Before;
	import org.junit.BeforeClass;
	import org.junit.Ignore;
	import org.junit.Test;

	import com.cg.ca.dao.ContactDaoImpl;
	import com.cg.ca.dao.IContactDao;
	import com.cg.ca.dto.Category;
	import com.cg.ca.dto.Contact;
	import com.cg.ca.dto.Gender;
	import com.cg.ca.exception.ContactException;

	public class TestContactDaoImpl {
		IContactDao dao=null;
		

		@BeforeClass
		public static void setUpBeforeClass() throws Exception {
		}

		@AfterClass
		public static void tearDownAfterClass() throws Exception {
		}

		@Before
		public void setUp() throws Exception {
			dao=new ContactDaoImpl();
			PropertyConfigurator.configure("res/log4j.properties");
		}

		
		@Test
		public void testAddNullContact(){
			try{
			Contact input=null;
			boolean expected=false;
			boolean actual=dao.add(input);
			assertTrue(expected==actual);
			}catch(ContactException e){
				fail("did not expect exception");
				
			}
					
		}
		@Test
		public void testAddNotNullContact(){
			try{
				Contact input=new Contact();
				input.setFirstName("Kavvya");
				input.setMidName("Pdad");
				input.setLastName("AS");
				input.setGender(Gender.FEMALE);
				input.setCategory(Category.FAMILY);
				input.setMobileNumber1("9654571230");
				input.setMobileNumber2("9810245843");
				input.setOfficialEmail("fdsdsdshg@capgemini.com");
				input.setHomeEmail("vawesdsdjfi@capgemini.com");
				input.setOrganization("cts");
		input.setDesignation("associates");
		boolean expected=true;
		boolean actual=dao.add(input);
		assertTrue(expected==actual);
			}catch(ContactException e){
				fail("Failed to Add new Student Exception" +e);
			}
		}
			@Test(expected=Exception.class)
			public void testAddNotNullContactwithInsufficientData() throws ContactException{
			Contact input=new Contact();
			input.setFirstName("Kathy");
			dao.add(input);
			fail("Expectiong an Exception");
		}
		
		@Test
		@Ignore ("Not Yet considered!")
		public void testMapRow() {
			fail("not yet implemented");
		}
		
		@Test
		@Ignore ("Not Yet considered!")
		public void testRemove() {
			fail("not yet implemented");
		}
		@Test
		@Ignore ("Not Yet consideres!")
		public void testUpdate() {
			fail("not yet implemented");
		}
		@Test
		@Ignore ("Not Yet considered!")
		public void testGetAll() {
			fail("not yet implemented");
		}
		@Test
		@Ignore ("Not Yet considered!")
		public void testGet() {
			fail("not yet implemented");
		
			
				
				

						
	}
	}


