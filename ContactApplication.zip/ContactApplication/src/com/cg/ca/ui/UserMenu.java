package com.cg.ca.ui;

public enum UserMenu {
	ADD,SEARCH,LIST,DELETE,QUIT;
}
