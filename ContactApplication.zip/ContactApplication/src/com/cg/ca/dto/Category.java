package com.cg.ca.dto;

public enum Category {
	FAMILY,FRIENDS,ACQUAINTANCE,WORK,OTHERS;

}
