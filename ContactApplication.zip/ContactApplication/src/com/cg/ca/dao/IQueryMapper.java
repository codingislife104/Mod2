package com.cg.ca.dao;


public interface IQueryMapper {
	public static final String INSERT_CONT_QRY="insert into Contacts (contId,firstName,midName,lastname,gender,mobileNUMBER1,mobileNUMBER2,officialEmail,homeEmail,category,organization,designation) values(contidseq.nextval,?,?,?,?,?,?,?,?,?,?,?)";
			
			public static final String DELETE_CONT_QRY="delete from Contacts where contId=?";
			public static final String SELECT_CONT_BY_ID_QRY="select contId,firstName,midName,lastname,gender,mobileNUMBER1,mobileNUMBER2,officialEmail,homeEmail,category,Organization,Designation from Contacts where contid=?";
			public static final String SELECT_ALL_CONT_QRY="select contId,firstName,midName,lastname,gender,mobileNUMBER1,mobileNUMBER2,officialEmail,homeEmail,category,Organization,Designation from Contacts";
}
