package com.cg.ca.exception;

public class ContactException extends Exception {

	public  ContactException(String Message){
	super(Message);

	}

}
