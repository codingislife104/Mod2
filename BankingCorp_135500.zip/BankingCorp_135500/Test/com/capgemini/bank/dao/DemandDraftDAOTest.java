package com.capgemini.bank.dao;

import static org.junit.Assert.*;

import java.sql.Date;
import java.time.LocalDate;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.Banking_Corp_Exceptions;

public class DemandDraftDAOTest {
	IDemandDraftDAO obj;
	@Before
	public void init()
	{
		 obj=new DemandDraftDAO();
		//before executing
	}
	@After
	public void destroy()
	{
		obj=null;
		//used to destroy
	}
	@Test
	public void addDemandDraftDetailsTest1() throws Banking_Corp_Exceptions {
		DemandDraft demandDraft=new DemandDraft();
		demandDraft.setCustName("Abc");
		demandDraft.setCustPhone("8013303788");
		demandDraft.setDdDraftAmmount(45000);
		demandDraft.setDdCommision(demandDraft.getDdDraftAmmount());
		demandDraft.setInFavourOf("Capgemini");
		demandDraft.setTransactionDate(LocalDate.now());
		demandDraft.setDdDraftDescription("DD taken in favour of Capgemini");
		obj.addDemandDraftDetails(demandDraft);
		assertEquals(demandDraft.getCustName(),"Abc");
	}
	@Test
	public void addDemandDraftDetailsTest2() throws Banking_Corp_Exceptions {
		DemandDraft demandDraft=new DemandDraft();
		demandDraft.setCustName("Abc");
		demandDraft.setCustPhone("8013303788");
		demandDraft.setDdDraftAmmount(45000);
		demandDraft.setDdCommision(demandDraft.getDdDraftAmmount());
		demandDraft.setInFavourOf("Capgemini");
		demandDraft.setTransactionDate(LocalDate.now());
		demandDraft.setDdDraftDescription("DD taken in favour of Capgemini");
		obj.addDemandDraftDetails(demandDraft);
		assertEquals(demandDraft.getDdCommision(),51);
	}
	@Test
	public void getDemandDraftDetailsTest1() throws Banking_Corp_Exceptions {
		DemandDraft demandDraft=new DemandDraft();
		DemandDraft demandDraft2=new DemandDraft();
		demandDraft=obj.getDemandDraftDetails(10050);
		demandDraft2.setDdCommision(51);
		demandDraft2.setDdDraftAmmount(45000);
		demandDraft2.setTransactionDate(LocalDate.now());
		demandDraft2.setDdDraftDescription("DD taken in favour of Capgemini");
		assertEquals(demandDraft2.getDdDraftAmmount(),demandDraft.getDdDraftAmmount());
	}
	@Test(expected=Banking_Corp_Exceptions.class)
	public void getDemandDraftDetailsTest2() throws Banking_Corp_Exceptions{
		DemandDraft demandDraft=new DemandDraft();
		DemandDraft demandDraft2=new DemandDraft();
		demandDraft=obj.getDemandDraftDetails(-070);
	}
}
