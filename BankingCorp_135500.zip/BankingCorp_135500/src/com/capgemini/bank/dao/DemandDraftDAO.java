package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.Banking_Corp_Exceptions;
import com.capgemini.bank.utility.DBConnection;


public class DemandDraftDAO implements IDemandDraftDAO {
	
	
	private static Logger logger=Logger.getLogger(DemandDraftDAO.class.getName());
	
	 static
	 {
		 PropertyConfigurator.configure("Resources/log4j.properties");
	 }
	 private int getTransactionId() throws Banking_Corp_Exceptions
	 {
		 int transactionId=0;
				logger.debug("Inside the Method searchStock() ");
				Connection connection = DBConnection.getConnection();
				DemandDraft demandDraft=new DemandDraft();
				String qry="select Transaction_Id_Seq.CURRVAL from dual";
				try(	Statement statement= connection.createStatement();
						ResultSet resultSet=statement.executeQuery(qry);)
				{
					logger.debug("Search query completed Successfully ");
						if(resultSet.next())
						{
							logger.debug("In the if Block "+resultSet.getInt(1));
							demandDraft.setTransaction_id(resultSet.getInt(1));
							logger.debug("Sequence current id is "+demandDraft.getTransaction_id());
							transactionId=demandDraft.getTransaction_id();
						}
						else
						{
							logger.debug("In the Else Block ");
						}
					
				} catch (SQLException e) {
					logger.error(" Error in fetching the Sequence current value "+e.getStackTrace());
					throw new Banking_Corp_Exceptions("Could not Retrive Sequence value from dual");
				}
				return transactionId;
	 }
	 /* (non-Javadoc)
	 * @see com.capgemini.bank.dao.IDemandDraftDAO#addDemandDraftDetails(com.capgemini.bank.bean.DemandDraft)
	 */
	@Override
	public void addDemandDraftDetails(DemandDraft demandDraft) throws Banking_Corp_Exceptions
		{
		 	
			logger.debug("Inside the Method addDemandDraftDetails() ");
			Connection connection = DBConnection.getConnection();
			String qry="Insert into demand_draft(transaction_id,customer_name, in_favour_of,phone_number,date_of_transaction, dd_ammount, dd_commision, dd_description) values (Transaction_Id_Seq.nextVal, ?, ?, ?, ?, ? , ? , ? ) ";
			try(
					PreparedStatement statement=connection.prepareStatement(qry);)
			{
				statement.setString(1,demandDraft.getCustName());
				statement.setString(2,demandDraft.getCustPhone());
				statement.setString(3,demandDraft.getInFavourOf());
				statement.setDate(4,Date.valueOf(demandDraft.getTransactionDate()));
				statement.setInt(5,demandDraft.getDdDraftAmmount());
				demandDraft.setDdCommision(demandDraft.getDdDraftAmmount());
				statement.setInt(6,demandDraft.getDdCommision());
				statement.setString(7,demandDraft.getDdDraftDescription());
				int noOfRowsinserted=statement.executeUpdate();
				connection.commit();
				logger.debug("Insert query Executed Successfully ");
				if (noOfRowsinserted==0)
				{
					logger.error("Unable to insert The Demand Draft Details for the Customer "+getTransactionId());
					throw new Banking_Corp_Exceptions("Unable to insert The Demand Draft Details for the Customer "+getTransactionId());
				}
				
			} catch (SQLException e) {
				logger.error("Error occured when inserting The Draft Details for the Customer "+e.getStackTrace());
				throw new Banking_Corp_Exceptions("Unable to insert The Demand Draft Details for the Customer "+getTransactionId());
			}
			System.out.println("Your Demand Draft request has been successfully registered Along with customer "+getTransactionId());
			logger.debug("Exiting the Method addDemandDraftDetails() ");
		}
	 /* (non-Javadoc)
	 * @see com.capgemini.bank.dao.IDemandDraftDAO#getDemandDraftDetails(int)
	 */
	@Override
	public DemandDraft getDemandDraftDetails(int transactionId)throws Banking_Corp_Exceptions
		{
			logger.debug("Inside the Method getDemandDraftDetails() ");
			DemandDraft demandDraft=new DemandDraft();
			Connection connection = DBConnection.getConnection();
			
			logger.debug("connection completed ");
			String qry="select dd_ammount, date_of_transaction, dd_description, dd_commision from demand_draft where transaction_id = ? ";
			logger.debug("query fired ");
			try(PreparedStatement statement=connection.prepareStatement(qry);)
			{
				statement.setInt(1, transactionId);
				logger.debug("Transaction Id setted "+transactionId);
				ResultSet resultSet=statement.executeQuery();
				logger.debug("Search query executed Successfully ");	
				if (resultSet.next())
				{
					logger.debug("Inside the if ");
					demandDraft.setDdDraftAmmount((resultSet.getInt(1)));
					demandDraft.setTransactionDate(resultSet.getDate(2).toLocalDate());
					demandDraft.setDdDraftDescription(resultSet.getString(3));
					demandDraft.setDdCommision((resultSet.getInt(4)));
					demandDraft.getDdTotalAmmount();
					logger.debug("object is "+demandDraft);
				}
				else
				{
					logger.error("Unable To find the Details with Transaction id "+transactionId);
					throw new Banking_Corp_Exceptions("Unable To find the Details with Transaction id "+transactionId);
				}
			} catch (SQLException e) {
				logger.error("Unable To find the Details with Transaction id "+e.getStackTrace());
				throw new Banking_Corp_Exceptions("Unable To find the Details with Transaction id "+transactionId);
			}
			logger.debug("Exiting the Method getDemandDraftDetails() ");
			return demandDraft;
		}
}
