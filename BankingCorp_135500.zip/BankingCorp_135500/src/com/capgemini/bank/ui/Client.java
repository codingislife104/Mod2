package com.capgemini.bank.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.Banking_Corp_Exceptions;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;

//Main method is calling from  Client Class
public class Client {
	
	//creating the objects needed
	IDemandDraftService dServices= new DemandDraftService();
	DemandDraft demandDraft=new DemandDraft();
	
	Scanner sc=new Scanner(System.in);
	
	//private function display menu
	private int displayMenu()
	{
		int choice;
		System.out.println("Display menu to the employee should be as follows");
		System.out.println("1) Enter Demand Draft Details");
		System.out.println("2) Print Demand Draft");
		System.out.println("3) Exit ");
		choice=sc.nextInt();
		return choice;
	}
	
	//private function from where the method are calling
	private void performTask(int choice) throws Banking_Corp_Exceptions
	{
		switch(choice)
		{
			case 1:
				demandDraft =get_DD_DetailsFromUser();
				//calling the function to insert the details into the database
				dServices.addDemandDraftDetails(demandDraft);
				break;
			case 2:
				demandDraft=getTransactionId();
				//calling the function to get the draft details according to the transaction id
				demandDraft=dServices.getDemandDraftDetails(demandDraft.getTransaction_id());
				printDraftDetails(demandDraft);
				break;
			case 3:
				//case 3 to exit
				System.out.println("You Are Exiting");
				System.exit(0);
				break;
			default:
				System.out.println("Enter A valid Option");
				break;
		}
	}
	
	// function to get the details from the user
	private DemandDraft get_DD_DetailsFromUser() throws Banking_Corp_Exceptions
	{
		DemandDraft demandDraft=new DemandDraft();
		System.out.print(" Enter The Name of The Customer : ");
		demandDraft.setCustName(sc.next());
		System.out.print(" Enter the Customer Phone Number : ");
		demandDraft.setCustPhone(sc.next());
		System.out.print(" In Favour of : ");
		demandDraft.setInFavourOf(sc.next());
		System.out.print(" Enter The Draft Ammount (in Rs. ) : ");
		demandDraft.setDdDraftAmmount(sc.nextInt());
		String str="DD taken in favour of Capgemini";
		System.out.println(" Enter Remarks : "+str);
		demandDraft.setDdDraftDescription(str);
		demandDraft.setTransactionDate(LocalDate.now());
		demandDraft.setDdCommision(demandDraft.getDdDraftAmmount());
		return demandDraft;
	}
	
	
	//function to get the transaction id from the user
	private DemandDraft getTransactionId() {
		DemandDraft demandDraft=new DemandDraft();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Transaction Id");
		demandDraft.setTransaction_id(sc.nextInt());
		return demandDraft;
	}
	
	//function to print the draft details which are fetched from the database
	private void printDraftDetails(DemandDraft demandDraft) throws Banking_Corp_Exceptions {
		System.out.println("Name of The Bank : XYZ ");
		System.out.println("DD Ammount : Rs. "+demandDraft.getDdDraftAmmount());
		System.out.println("DD Commision : Rs. "+demandDraft.getDdCommision());
		System.out.println("Total Ammount : Rs.  "+demandDraft.getDdTotalAmmount());
		System.out.println("Transaction Date  "+demandDraft.getTransactionDate());
		System.out.println("Remarks  "+demandDraft.getDdDraftDescription());
	}
	
	//main method
	public static void main(String args[])
	{
		int option;
		Client obj=new Client();
		while (true)
		{
			option=obj.displayMenu();
			try {
				obj.performTask(option);
			} catch (Banking_Corp_Exceptions e) {
				System.out.println("********************************");
				System.out.println(" "+e.getMessage());
				System.out.println("********************************");
			}
		}
	}
	
}