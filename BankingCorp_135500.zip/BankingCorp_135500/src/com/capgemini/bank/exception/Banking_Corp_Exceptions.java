package com.capgemini.bank.exception;


	 public class Banking_Corp_Exceptions extends Exception
	 {
	 	public Banking_Corp_Exceptions(String s)
	 	{
	 		super(s);
	 	}
	 }
