package com.capgemini.bank.bean;

import java.time.LocalDate;

import com.capgemini.bank.exception.Banking_Corp_Exceptions;

public class DemandDraft {
	private int transaction_id;
	private String custName;
	private String inFavourOf;
	private String custPhone;
	private LocalDate transactionDate;
	private int ddDraftAmmount;
	private String ddDraftDescription;
	private int ddCommision;
	private int ddTotalAmmount;
	public int getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(int transaction_id) {
		this.transaction_id = transaction_id;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getInFavourOf() {
		return inFavourOf;
	}
	public void setInFavourOf(String inFavourOf) {
		this.inFavourOf = inFavourOf;
	}
	public String getCustPhone() {
		return custPhone;
	}
	public void setCustPhone(String custPhone) {
		this.custPhone = custPhone;
	}
	public LocalDate getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}
	public int getDdDraftAmmount() {
		return ddDraftAmmount;
	}
	public void setDdDraftAmmount(int d) {
		this.ddDraftAmmount = d;
	}
	public String getDdDraftDescription() {
		return ddDraftDescription;
	}
	public void setDdDraftDescription(String ddDraftDescrition) {
		this.ddDraftDescription = ddDraftDescrition;
	}
	public int getDdCommision() {
		return ddCommision;
	}
	public int getDdTotalAmmount() throws Banking_Corp_Exceptions
	{
		this.ddCommision=getDdCommision();
		this.ddTotalAmmount=(this.ddDraftAmmount+this.ddCommision);
		return this.ddTotalAmmount;
		
	}
	public int setDdCommision(int ddDraftAmmount) throws Banking_Corp_Exceptions
	{
		if ((ddDraftAmmount<5001)&& (ddDraftAmmount>0))
		{
			this.ddCommision=10;
			return ddCommision;
		}
		else if((ddDraftAmmount>5000) && (ddDraftAmmount<10001))
		{
			this.ddCommision=41;
			return ddCommision;
		}
		else if((ddDraftAmmount>10000) && (ddDraftAmmount<100001))
		{
			this.ddCommision=51;
			return ddCommision;
		}
		else if((ddDraftAmmount>100000) && (ddDraftAmmount<500001))
		{
			this.ddCommision=306;
			return ddCommision;
		}
		else
		{
			throw new Banking_Corp_Exceptions("Invalid Ammount Entered");
		}
	}
	@Override
	public String toString() {
		return "DemandDraft [transaction_id = " + transaction_id + ", custName = "
				+ custName + ", inFavourOf=" + inFavourOf + ", custPhone="
				+ custPhone + ", transactionDate=" + transactionDate
				+ ", ddDraftAmmount=" + ddDraftAmmount
				+ ", ddDraftDescription=" + ddDraftDescription
				+ ", ddCommision=" + ddCommision + ", ddTotalAmmount="
				+ ddTotalAmmount + "]";
	}
	
}
