package com.capgemini.bank.utility;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.capgemini.bank.exception.Banking_Corp_Exceptions;

public class DBConnection {
	static Connection con;
	public static Connection getConnection() throws Banking_Corp_Exceptions
	{
		Properties prop=new Properties();
		try
		{
			FileReader reader=new FileReader("User.properties");
			prop.load(reader);
			String username=prop.getProperty("username");
			String password=prop.getProperty("password");
			String url=prop.getProperty("url");
			String driverName=prop.getProperty("driverName");
		if (con==null)
		{			
				Class.forName(driverName);
				con=DriverManager.getConnection(url,username,password);
				con.setAutoCommit(false);
		}
		} catch (SQLException | ClassNotFoundException e) {
				throw new Banking_Corp_Exceptions("Database Connection Failed");
		}catch(IOException e)
		{
			throw new Banking_Corp_Exceptions("Unable to read the Property File!!!");
		}
		return con;
	}
}
