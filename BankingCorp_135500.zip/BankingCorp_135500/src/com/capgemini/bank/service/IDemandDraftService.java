package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.Banking_Corp_Exceptions;

public interface IDemandDraftService {

	
	public abstract void addDemandDraftDetails(DemandDraft demandDraft)throws Banking_Corp_Exceptions;

	
	public abstract DemandDraft getDemandDraftDetails(int transactionId)throws Banking_Corp_Exceptions;

}