package com.capgemini.bank.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.exception.Banking_Corp_Exceptions;

public class DemandDraftService implements IDemandDraftService {
	
	IDemandDraftDAO dao=new DemandDraftDAO();
	
	//function to validate the name inputed by the user
	private boolean validateName(String name) throws Banking_Corp_Exceptions
	{
		String regExpress="^[A-Z]{1}+[a-z]{1,19}$";
		Pattern pattern=Pattern.compile(regExpress);
		Matcher matcher=pattern.matcher(name);
		if(matcher.find())
		{
			return true;
		}
		else
		{
			throw new Banking_Corp_Exceptions("Enter a valid Name first Alphabet Should be capital and else be small and max length 20");
		}
	}
	
	//function to validate the in favour of  inputed by the user
	private boolean validateInfavourOf(String name) throws Banking_Corp_Exceptions
	{
		String regExpress="^[A-Z]{1}+[a-z]{1,19}$";
		Pattern pattern=Pattern.compile(regExpress);
		Matcher matcher=pattern.matcher(name);
		if(matcher.find())
		{
			return true;
		}
		else
		{
			throw new Banking_Corp_Exceptions("Enter a valid In favour of name  first Alphabet Should be capital and else be small and max length 20");
		}
	}
	
	//function to validate the phone number inputed by the user
	private boolean validatePhoneNumber(String PhoneNumber) throws Banking_Corp_Exceptions
	{
		String regExpress="^[0-9]{10}$";
		Pattern pattern=Pattern.compile(regExpress);
		Matcher matcher=pattern.matcher(PhoneNumber);
		if(matcher.find())
		{
			return true;
		}
		else
		{
			throw new Banking_Corp_Exceptions("Enter a valid phone number it must be of only numbers and only 10 digits");
		}
	}
	
	//function to validate the draft inputed by the user
	private boolean validateDraftAmmount(int dAmmount) throws Banking_Corp_Exceptions
	{
		String regExpress="^[0-9]{6}$";
		Pattern pattern=Pattern.compile(regExpress);
		String str=String.valueOf(dAmmount);
		Matcher matcher=pattern.matcher(str);
		if(matcher.find())
		{
			return true;
		}
		else
		{
			throw new Banking_Corp_Exceptions("Enter a valid Ammount it should not exceed 5,00,000");
		}
	}
	
	//function to validate the transaction id inputed by the user
	private boolean validateTransactionId(int transactionId) throws Banking_Corp_Exceptions
	{
		String regExpress="^[0-9]{5}$";
		String str=String.valueOf(transactionId);
		Pattern pattern=Pattern.compile(regExpress);
		Matcher matcher=pattern.matcher(str);
		if(matcher.find())
		{
			return true;
		}
		else
		{
			throw new Banking_Corp_Exceptions("Enter a valid Transaction Id It should be only 5 digits");
		}
	}
	
	
	/* (non-Javadoc)
	 * @see com.capgemini.bank.service.IDemandDraftService#addDemandDraftDetails(com.capgemini.bank.bean.DemandDraft)
	 */
	@Override
	public void addDemandDraftDetails(DemandDraft demandDraft) throws Banking_Corp_Exceptions
	{
		//calling the validate functions..
		validateName(demandDraft.getCustName());
		validatePhoneNumber(demandDraft.getCustPhone());
		validateInfavourOf(demandDraft.getInFavourOf());
		
		dao.addDemandDraftDetails(demandDraft);
	}
	
	
	/* (non-Javadoc)
	 * @see com.capgemini.bank.service.IDemandDraftService#getDemandDraftDetails(int)
	 */
	@Override
	public DemandDraft getDemandDraftDetails(int transactionId)throws Banking_Corp_Exceptions
	{
		//calling the validate function of transaction id
		validateTransactionId(transactionId);
		return dao.getDemandDraftDetails(transactionId);
	}
	
}
