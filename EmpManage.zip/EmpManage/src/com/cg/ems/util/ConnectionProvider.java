package com.cg.ems.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class ConnectionProvider {

	private String dbUserName;
	private String dbPassword;
	private String dbUrl;
	private String dbDriver;

	private static ConnectionProvider ConnectionProviderObject;

	private ConnectionProvider(String configFileName)
			throws FileNotFoundException, IOException, ClassNotFoundException {
		Properties prop = new Properties();
		prop.load(new FileInputStream(configFileName));

		dbUserName = prop.getProperty("db.uid");
		dbPassword = prop.getProperty("db.pwd");
		dbUrl = prop.getProperty("db.url");
		dbDriver = prop.getProperty("db.driver");

		Class.forName(dbDriver);
	}

	public static ConnectionProvider getInstance(String configFileName)
			throws FileNotFoundException, ClassNotFoundException, IOException {
		if (ConnectionProviderObject == null)
			ConnectionProviderObject = new ConnectionProvider(configFileName);

		return ConnectionProviderObject;
	}
	
	public Connection getConnection() throws SQLException{
		
		return DriverManager.getConnection(dbUrl,dbUserName,dbPassword);
	}

}
