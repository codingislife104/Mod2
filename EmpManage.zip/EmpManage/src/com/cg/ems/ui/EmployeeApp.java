package com.cg.ems.ui;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.cg.ems.dto.Employee;
import com.cg.ems.dto.Gender;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmployeeServiceImpl;
import com.cg.ems.service.IEmployeeService;

public class EmployeeApp {
	
	static IEmployeeService service;
	static Scanner scan;


	public static void main(String[] args) {
		
		PropertyConfigurator.configure("res/log4j.properties");
		try {
			service = new EmployeeServiceImpl();
			System.out.println("Service Started!");
		} catch (EmployeeException exp) {
			System.err.println(exp.getMessage());
			System.exit(0);
		}

		UserMenu choice = null;
		scan = new Scanner(System.in);
		
		while (choice != UserMenu.QUIT) {

			System.out.println("********* EMPLOYEE **********");
			System.out.println("CHOICE\t MENU");
			System.out.println("==========================");
			for (UserMenu menuItem : UserMenu.values()) {
				System.out.println(menuItem.ordinal() + "\t" + menuItem.name());
			}
			
			System.out.println("Enter Choice: ");
			int ordinal = scan.nextInt();

			if (ordinal < 0 || ordinal > UserMenu.QUIT.ordinal()) {
				System.err.println("Invalid Choice...");
				continue;
			}

			choice = UserMenu.values()[ordinal];
			
			switch (choice) {
			case ADD:
				doAdd();
				break;
			case SEARCH:
				doSearch();
				break;
			case LIST:
				doList();
				break;
			case DELETE:
				doDelete();
				break;
			case QUIT:
				System.out.println("Thank You!");
				break;
		}	
		
	}
		scan.close();

}


	private static void doDelete() {
		
		try {
			System.out.println("Enter EmployeeId: ");
			int contId = scan.nextInt();
			Employee employee = service.get(contId);
			if (employee == null) {
				System.out.println("Employee Not Found!");
			} else {
				boolean isSuccessful = service.remove(employee.getEmployeeId());
				if (isSuccessful)
					System.out.println("Employee deleted!");
				else
					System.out.println("Employee could not be deleted!");
			}
		} catch (EmployeeException exp) {
			System.out.println(exp.getMessage());
		}
		
	}


	private static void doList() {
		
		try {
			List<Employee> employees = service.getAll();
			for (Employee employee : employees) {
				System.out.println(employee);
			}
		} catch (EmployeeException exp) {
			System.err.println(exp.getMessage());
		}
		
	}


	private static void doSearch() {
		
		System.out.print("Enter Employee Id: ");
		int contId = scan.nextInt();
		try {
			Employee employee = service.get(contId);
			if (employee == null) {
				System.out.println("Employee Not Found!");
			} else {
				System.out.println(employee);
			}
		} catch (EmployeeException exp) {
			System.err.println(exp.getMessage());
		}
	}
		


	private static void doAdd() {
		
		Employee employee = new Employee();

		System.out.println("Enter Employee Name: ");
		employee.setEmployeeName(scan.next());
		System.out.println("Enter Gender(" + Arrays.toString(Gender.values())
				+ "):");
		employee.setGender(Gender.valueOf(scan.next().toUpperCase()));
		
		System.out.println("Enter basic: ");
		employee.setBasic(scan.nextDouble());
		
		try {
			boolean isSuccessful = service.add(employee);
			if (isSuccessful)
				System.out.println("Employee successfully added!");
			else
				System.out.println("Employee could not be added!");
		} catch (EmployeeException exp) {
			System.err.println(exp.getMessage());
		}
	}

}
