package com.cg.ems.dto;

public class Employee {
	
	private int employeeId;
	private String employeeName;
	private Gender gender;
	private double basic;
	
	public Employee(){
		//default constructor
	}

	public Employee(int employeeId, String employeeName, Gender gender,
			double basic) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.gender = gender;
		this.basic = basic;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public double getBasic() {
		return basic;
	}

	public void setBasic(Double basic) {
		this.basic = basic;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName="
				+ employeeName + ", gender=" + gender + ", basic=" + basic
				+ "]";
	}

	
	
}
