package com.cg.ems.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.dao.IEmployeeDao;
import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService {

	private IEmployeeDao dao = null;

	private List<String> validationErrors;

	public EmployeeServiceImpl() throws EmployeeException {
		dao = new EmployeeDaoImpl();
	}

	public boolean isValidEmployeeID(int empId) {
		return empId > 0 ? true : false;
	}

	public boolean isValidEmployeeName(String name) {
		Pattern namePattern = Pattern.compile("[A-Z]{1}[a-zA-Z\\s]{3,25}");
		Matcher nameMatcher = namePattern.matcher(name);
		return nameMatcher.matches();
	}

	@Override
	public boolean add(Employee employee) throws EmployeeException {
		boolean result = false;
		if (isValidEmployee(employee)) {
			result = dao.add(employee);
		} else {
			throw new EmployeeException("Can't have Invalid Employee!"
					+ validationErrors);
		}
		return result;
	}

	private boolean isValidEmployee(Employee employee) {
		validationErrors = new ArrayList<>();
		if (employee != null) {
			if (!isValidEmployeeName((employee.getEmployeeName()))) {
				validationErrors
						.add("Firt name must start with capital and should be between 4 to 26 chars");
			}

		}
		return validationErrors.size() == 0 ? true : false;
	}

	@Override
	public boolean remove(int empId) throws EmployeeException {
		return dao.remove(empId);
	}

	@Override
	public Employee get(int empId) throws EmployeeException {
		return dao.get(empId);
	}

	@Override
	public List<Employee> getAll() throws EmployeeException {
		return dao.getAll();
	}

}
