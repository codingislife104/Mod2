package com.cg.ems.dao;

public interface IQueryMapper {
	
	public static final String INSERT_EMP_QRY=
			"insert into employee (empid,empname,gender,basic) values(empidseq.nextval,?,?,?)";
	
	public static final String DELETE_EMP_QRY=
			"delete from employee where empid=?";
	
	public static final String SELECT_EMP_BY_ID_QRY=
			"select empid,empname,gender,basic from employee where empid=?";
	
	public static final String SELECT_ALL_EMP_QRY=
			"select empid,empname,gender,basic from employee ";

}
