package com.cg.ems.dao;

import java.util.List;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;

public interface IEmployeeDao {

public boolean add (Employee employee) throws EmployeeException;
	
	public boolean remove(int empid) throws EmployeeException;
	
	public Employee get(int empid) throws EmployeeException;
	
	public List<Employee> getAll() throws EmployeeException;
	
}
