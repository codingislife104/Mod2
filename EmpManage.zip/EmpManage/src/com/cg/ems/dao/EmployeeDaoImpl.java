package com.cg.ems.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.ems.dto.Employee;
import com.cg.ems.dto.Gender;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.ConnectionProvider;

public class EmployeeDaoImpl implements IEmployeeDao {

	private Logger classLogger;
	private ConnectionProvider conPro;

	public EmployeeDaoImpl() throws EmployeeException {
		classLogger = Logger.getLogger(EmployeeDaoImpl.class);
		try {
			conPro = ConnectionProvider.getInstance("res/jdbc.properties");
		} catch (ClassNotFoundException | IOException exp) {
			classLogger.error(exp);
			throw new EmployeeException("Data Access Initiation Failed!");
		}

	}

	public Employee mapRow(ResultSet row) throws EmployeeException {
		Employee employee = new Employee();
		try {
			employee.setEmployeeId(row.getInt("empId"));
			employee.setEmployeeName(row.getString("empname"));
			employee.setGender(Gender.valueOf(row.getString("gender")));
			employee.setBasic(row.getDouble("basic"));

		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new EmployeeException("Failed to retrieve data!");
		}
		return employee;
	}

	@Override
	public boolean add(Employee employee) throws EmployeeException {
		boolean result = false;
		if (employee != null) {
			try (Connection con = conPro.getConnection();
					PreparedStatement pstInsert = con
							.prepareStatement(IQueryMapper.INSERT_EMP_QRY)) {
				classLogger.debug(employee + "being added!");
				pstInsert.setString(1, employee.getEmployeeName());
				pstInsert.setString(2, employee.getGender().toString());
				pstInsert.setDouble(3, employee.getBasic());

				classLogger.debug("3 values are added to pst insert");
				int count = pstInsert.executeUpdate();
				if (count > 0) {
					result = true;
				}
			} catch (SQLException exp) {
				classLogger.error(exp);
				throw new EmployeeException("Failed to add record!");
			}
		}
		return result;
	}

	@Override
	public boolean remove(int empid) throws EmployeeException {

		boolean result = false;
		try (Connection con = conPro.getConnection();
				PreparedStatement pstDelete = con
						.prepareStatement(IQueryMapper.DELETE_EMP_QRY)) {

			pstDelete.setInt(1, empid);
			int count = pstDelete.executeUpdate();
			if (count > 0) {
				result = true;
			}
		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new EmployeeException("Failed to Delete record!");
		}
		return result;
	}

	@Override
	public Employee get(int empid) throws EmployeeException {

		Employee employee = null;
		try (Connection con = conPro.getConnection();
				PreparedStatement pstSelectById = con
						.prepareStatement(IQueryMapper.SELECT_EMP_BY_ID_QRY)) {

			pstSelectById.setInt(1, empid);
			ResultSet result = pstSelectById.executeQuery();
			if (result.next())
				employee = mapRow(result);
		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new EmployeeException("Failed to get record!");
		}
		return employee;
	}

	@Override
	public List<Employee> getAll() throws EmployeeException {

		List<Employee> employeeList = new ArrayList<>();
		try (Connection con = conPro.getConnection();
				PreparedStatement pstSelectAll = con
						.prepareStatement(IQueryMapper.SELECT_ALL_EMP_QRY)) {

			ResultSet results = pstSelectAll.executeQuery();
			while (results.next()) {
				employeeList.add(mapRow(results));
			}
		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new EmployeeException("Failed to retreive record!");
		}
		return employeeList;
	}

}
