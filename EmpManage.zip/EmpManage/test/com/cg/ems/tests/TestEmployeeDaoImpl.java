package com.cg.ems.tests;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.apache.log4j.PropertyConfigurator;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.dao.IEmployeeDao;
import com.cg.ems.dto.Employee;
import com.cg.ems.dto.Gender;
import com.cg.ems.exception.EmployeeException;

public class TestEmployeeDaoImpl {
	
	IEmployeeDao dao = null;

	@Before
	public void setUp() throws Exception {
		dao = new EmployeeDaoImpl();
		PropertyConfigurator.configure("res/log4j.properties");
	}

	@After
	@Ignore("Not yet Considered")
	public void tearDown() throws Exception {
	}

	@Test
	public void testAddNull() {
		try {
			Employee input = null;
			boolean expected = false;
			boolean actual = dao.add(input);
			assertTrue(expected == actual);
		} catch (EmployeeException e) {
			fail("Did not expect exception");
		}
	}
	
	@Test
	public void testAddNotNUllContact() {
		try {
			Employee input = new Employee();
			input.setEmployeeName("Hari");
			input.setGender(Gender.MALE);
			input.setBasic(5000.00);
			boolean expected = true;
			boolean actual = dao.add(input);
			assertTrue(expected == actual);
		} catch (EmployeeException e) {
			fail("Failed to add new Employee exception" + e);

		}
	}
	
	@Test(expected = Exception.class)
	public void testAddNotNullContactWithInsufficientData()
			throws EmployeeException {
		Employee input = new Employee();
		input.setEmployeeName("Raji");
		dao.add(input);
		fail("Expecting exception");

	}

	@Test
	@Ignore("Not yet Considered")
	public void testRemove() {
		fail("Not yet implemented");
	}

	@Test
	@Ignore("Not yet Considered")
	public void testGet() {
		fail("Not yet implemented");
	}

	@Test
	@Ignore("Not yet Considered")
	public void testGetAll() {
		fail("Not yet implemented");
	}

}
