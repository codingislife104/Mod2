create table Employee(
		empid number(4) Primary key,
		empName varchar(15) not null,
		gender varchar(10) not null,
		basic number(10,4) not null
		);


create sequence empIdSeq
	start with 1
	increment by 1;