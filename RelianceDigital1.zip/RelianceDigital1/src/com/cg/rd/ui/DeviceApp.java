package com.cg.rd.ui;

import java.util.Arrays;

import java.util.List;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.cg.rd.dto.Category;
import com.cg.rd.dto.Device;

import com.cg.rd.exception.DeviceException;
import com.cg.rd.service.DeviceServiceImpl;
import com.cg.rd.service.IDeviceService;

public class DeviceApp {

	static IDeviceService service;
	static Scanner scan;

	public static void main(String[] args) {
		PropertyConfigurator.configure("res/log4j.properties");
		try {
			service = new DeviceServiceImpl();
			System.out.println("Service Started!");
		} catch (DeviceException exp) {
			System.err.println(exp.getMessage());
			System.exit(0);
		}

		UserMenu choice = null;
		scan = new Scanner(System.in);

		while (choice != UserMenu.QUIT) {

			System.out.println("********* RELIANCE DIGITAL DEVICES **********");
			System.out.println("CHOICE\t MENU");
			System.out.println("==========================");
			for (UserMenu menuItem : UserMenu.values()) {
				System.out.println(menuItem.ordinal() + "\t" + menuItem.name());
			}

			System.out.println("Enter Choice: ");
			int ordinal = scan.nextInt();

			if (ordinal < 0 || ordinal > UserMenu.QUIT.ordinal()) {
				System.err.println("Invalid Choice...");
				continue;
			}

			choice = UserMenu.values()[ordinal];

			switch (choice) {
			case ADD:
				doAdd();
				break;
			case LIST:
				doList();
				break;
			case QUIT:
				System.out.println("Thank You!");
				break;
			}
		}
		scan.close();
	}

	public static void doAdd() {
		Device device = new Device();

		System.out.println("Enter Title: ");
		device.setTitle(scan.next());
		System.out.println("Enter Price : ");
		device.setPrice(scan.nextDouble());
		System.out.println("Enter Category("
				+ Arrays.toString(Category.values()) + "):");
		device.setCategory(Category.valueOf(scan.next().toUpperCase()));

		System.out.println("Enter Manufacturer : ");
		device.setManufacturer(scan.next());

		try {
			int c = service.add(device);
			// int cid = service.add(device);
			if (c > -1)
				System.out
						.println("Device successfully added!" + c + " ADDED ");
			else
				System.out.println("Device could not be added!");
		} catch (DeviceException exp) {
			System.err.println(exp.getMessage());
		}
	}

	/*
	 *  
	 */
	public static void doList() {
		System.out.print("Enter Category Name: ");
		Category crg = Category.valueOf(scan.next().toUpperCase());

		try {

			List<Device> devices = service.getAllByCategory(crg);
			if (devices == null || devices.size() == 0) {
				System.out.println("Device Not Found!");
			} else {
				for (Device device : devices) {
					System.out.println(device);
				}
			}
		} catch (DeviceException exp) {
			System.err.println(exp.getMessage());
		}
	}

}
