package com.cg.rd.ui;

public enum UserMenu {
	ADD,LIST,QUIT;
}
