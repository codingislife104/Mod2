package com.cg.rd.dto;

public enum Category {
LAPTOP,CAMERA,ACCESSORY,APPLIANCE;
}
