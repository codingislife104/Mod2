package com.cg.rd.dao;

import java.util.List;
import com.cg.rd.dto.*;

import com.cg.rd.dto.Device;
import com.cg.rd.exception.DeviceException;

public interface IDeviceDao {
	public int add(Device contact) throws DeviceException;
	public List<Device> getAllByCategory(Category crg) throws DeviceException;
}
