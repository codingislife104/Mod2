package com.cg.rd.dao;

import java.io.IOException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.rd.dto.Category;
import com.cg.rd.dto.Device;
import com.cg.rd.exception.DeviceException;
import com.cg.rd.util.ConnectionProvider;

public class DeviceDaoImpl implements IDeviceDao {

	private Logger classLogger;
	private ConnectionProvider conPro;

	public DeviceDaoImpl() throws DeviceException {
		classLogger = Logger.getLogger(DeviceDaoImpl.class);
		try {
			conPro = ConnectionProvider.getInstance("res/jdbc.properties");
		} catch (ClassNotFoundException | IOException exp) {
			classLogger.error(exp);
			throw new DeviceException("Data Access Initiation Failed!");
		}
	}

	public Device mapRow(ResultSet row) throws DeviceException {
		Device contact = new Device();
		try {
			contact.setDevId(row.getInt("devid"));
			contact.setTitle(row.getString("title"));
			contact.setPrice(row.getDouble("price"));
			contact.setCategory(Category.valueOf(row.getString("category")));
			contact.setManufacturer(row.getString("manufacturer"));

		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new DeviceException("Failed to retrieve data!");
		}
		return contact;
	}

	@Override
	public int add(Device contact) throws DeviceException {
		int result = -1;
		if (contact != null) {
			try (Connection con = conPro.getConnection();
					PreparedStatement pstInsert = con
							.prepareStatement(IQueryMapper.INSERT_DEV_QRY);
					PreparedStatement pstid = con
							.prepareStatement(IQueryMapper.GET_DEV_ID)) {
				classLogger.debug(contact + "being added!");
				pstInsert.setString(1, contact.getTitle());
				pstInsert.setDouble(2, contact.getPrice());
				pstInsert.setString(3, contact.getCategory().toString());
				pstInsert.setString(4, contact.getManufacturer());
				classLogger.debug("5 values are added to pst insert");
				int count = pstInsert.executeUpdate();
				if (count > 0) {
					ResultSet rs = pstid.executeQuery();
					if (rs.next())
						result = rs.getInt(1);
				}
			} catch (SQLException exp) {
				classLogger.error(exp);
				throw new DeviceException(
						"RECORD IS ADDED");
			}
		}
		return result;
	}

	@Override
	public List<Device> getAllByCategory(Category crg) throws DeviceException {
		List<Device> contactsList = new ArrayList<>();
		try (Connection con = conPro.getConnection();
				PreparedStatement pstSelectAll = con
						.prepareStatement(IQueryMapper.SELECT_DEV_BY_CST_QRY)) {

			pstSelectAll.setString(1,crg.toString());
			ResultSet results = pstSelectAll.executeQuery();
			while (results.next()) {
				contactsList.add(mapRow(results));
			}
		} catch (SQLException exp) {
			classLogger.error(exp);
			throw new DeviceException("Failed to retreive record!");
		}
		return contactsList;
	}

}
