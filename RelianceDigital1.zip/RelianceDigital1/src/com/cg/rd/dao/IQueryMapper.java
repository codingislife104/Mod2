package com.cg.rd.dao;

public interface IQueryMapper {

	public static final String INSERT_DEV_QRY = "INSERT INTO ElectronicDevices(devid,title,price,category,manufacturer) VALUES(devseq.nextval,?,?,?,?)";

	public static final String SELECT_DEV_BY_CST_QRY = "SELECT * FROM ElectronicDevices WHERE category=?";

	public static final String GET_DEV_ID = "SELECT devseq.currVal FROM dual ";
}
