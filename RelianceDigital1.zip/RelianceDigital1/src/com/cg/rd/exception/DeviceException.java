package com.cg.rd.exception;

@SuppressWarnings("serial")
public class DeviceException extends Exception {
	public DeviceException(String message){
		super(message);
	}

}
