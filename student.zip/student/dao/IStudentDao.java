package com.cg.student.dao;

public interface IStudentDao {

}
