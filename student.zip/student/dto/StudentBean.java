package com.cg.student.dto;

import java.time.LocalDate;

public class StudentBean {
	String studentid;
	String studentname;
	int age;
	
	int phonenumber;
	String grade;
	public String getStudentid() {
		return studentid;
	}
	public void setStudentid(String studentid) {
		this.studentid = studentid;
	}
	public String getStudentname() {
		return studentname;
	}
	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(int phonenumber) {
		this.phonenumber = phonenumber;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	
	@Override
	public String toString() {
		return "StudentBean [studentid=" + studentid + ", studentname="
				+ studentname + ", age=" + age + ", phonenumber=" + phonenumber
				+ ", grade=" + grade + "]";
	}
	
}
