package com.cg.ars.bean;

import java.util.Date;

public class FlightInformationBean {

	private String flightNumber; 
	private String airline;
	private String departureCity; 
	private String arrivalCity; 
	private Date deppartureDate; 
	private String deppartureTime;
	private String arrivalTime; 
	private int firstSeats;
	private float firstSeatFare;
	private int bussSeats;
	private float bussSeatsFare;
	public String getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	public String getDepartureCity() {
		return departureCity;
	}
	public void setDepartureCity(String departureCity) {
		this.departureCity = departureCity;
	}
	public String getArrivalCity() {
		return arrivalCity;
	}
	public void setArrivalCity(String arrivalCity) {
		this.arrivalCity = arrivalCity;
	}
	public Date getDeppartureDate() {
		return deppartureDate;
	}
	public void setDeppartureDate(Date deppartureDate) {
		this.deppartureDate = deppartureDate;
	}
	public String getDeppartureTime() {
		return deppartureTime;
	}
	public void setDeppartureTime(String deppartureTime) {
		this.deppartureTime = deppartureTime;
	}
	public String getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	public int getFirstSeats() {
		return firstSeats;
	}
	public void setFirstSeats(int firstSeats) {
		this.firstSeats = firstSeats;
	}
	public float getFirstSeatFare() {
		return firstSeatFare;
	}
	public void setFirstSeatFare(float firstSeatFare) {
		this.firstSeatFare = firstSeatFare;
	}
	public int getBussSeats() {
		return bussSeats;
	}
	public void setBussSeats(int bussSeats) {
		this.bussSeats = bussSeats;
	}
	public float getBussSeatsFare() {
		return bussSeatsFare;
	}
	public void setBussSeatsFare(float bussSeatsFare) {
		this.bussSeatsFare = bussSeatsFare;
	}
	public FlightInformationBean(String flightNumber, String airline,
			String departureCity, String arrivalCity, Date deppartureDate,
			String deppartureTime, String arrivalTime, int firstSeats,
			float firstSeatFare, int bussSeats, float bussSeatsFare) {
		super();
		this.flightNumber = flightNumber;
		this.airline = airline;
		this.departureCity = departureCity;
		this.arrivalCity = arrivalCity;
		this.deppartureDate = deppartureDate;
		this.deppartureTime = deppartureTime;
		this.arrivalTime = arrivalTime;
		this.firstSeats = firstSeats;
		this.firstSeatFare = firstSeatFare;
		this.bussSeats = bussSeats;
		this.bussSeatsFare = bussSeatsFare;
	}
	public FlightInformationBean() {
		super();
	}
	@Override
	public String toString() {
		return "FlightInformationBean [flightNumber=" + flightNumber
				+ ", airline=" + airline + ", departureCity=" + departureCity
				+ ", arrivalCity=" + arrivalCity + ", deppartureDate="
				+ deppartureDate + ", deppartureTime=" + deppartureTime
				+ ", arrivalTime=" + arrivalTime + ", firstSeats=" + firstSeats
				+ ", firstSeatFare=" + firstSeatFare + ", bussSeats="
				+ bussSeats + ", bussSeatsFare=" + bussSeatsFare + "]";
	}
	

}
