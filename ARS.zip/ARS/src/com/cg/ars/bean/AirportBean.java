package com.cg.ars.bean;

public class AirportBean {
	private String AirportName; 
	private String Abbreviation; 
	private String Location;
	public String getAirportName() {
		return AirportName;
	}
	public void setAirportName(String airportName) {
		AirportName = airportName;
	}
	public String getAbbreviation() {
		return Abbreviation;
	}
	public void setAbbreviation(String abbreviation) {
		Abbreviation = abbreviation;
	}
	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}
	public AirportBean(String airportName, String abbreviation, String location) {
		super();
		AirportName = airportName;
		Abbreviation = abbreviation;
		Location = location;
	}
	public AirportBean() {
		super();
	}
	@Override
	public String toString() {
		return "AirportBean [AirportName=" + AirportName + ", Abbreviation="
				+ Abbreviation + ", Location=" + Location + "]";
	}
	
	
}
