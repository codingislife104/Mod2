package com.cg.ars.dao;

import com.cg.ars.exception.ARSException;


public interface IUserDAO {
	public String validUser(String userName,String password,String role,long mobileNo) throws ARSException;
	
}
