package com.capgemini.tcc.service;

import java.util.List;

import com.capgemini.tcc.been.PatientBean;
import com.capgemini.tcc.exception.PatientException;

public interface IPatientService {
	
	public String insertPatientDetails(PatientBean patientBean)
			throws PatientException;
	
	public List<PatientBean> search(final int patientid)
			throws PatientException;
			
}
