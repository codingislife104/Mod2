package com.capgemini.tcc.exception;

public class PatientException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PatientException() {
		// TODO Auto-generated constructor stub
	}

	public PatientException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	

}
