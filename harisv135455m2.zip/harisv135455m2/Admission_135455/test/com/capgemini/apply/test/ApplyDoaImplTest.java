package com.capgemini.apply.test;

import static org.junit.Assert.assertEquals;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.junit.Test;

import com.capgemini.apply.bean.ApplicantBean;
import com.capgemini.apply.dao.DBUtil;
import com.capgemini.apply.dao.QueryMapper;

public class ApplyDoaImplTest {

	Connection c = DBUtil.getConnection();
	ApplicantBean ai = new ApplicantBean();
	private int n;

	@Test
	public void testAddApplicantDetails() {
		c = DBUtil.getConnection();
		try {
			PreparedStatement ps = c.prepareStatement(QueryMapper.INSERT);

			ai.setFname("Hari");
			ai.setLname("prasad");
			ai.setMno(9750788838L);
			ai.setEmail("Prasad3@gmail.com");
			ai.setStream("BSc");
			ai.setAggregate(90);

			ps.setString(1, ai.getFname());
			ps.setString(2, ai.getLname());
			ps.setLong(3, ai.getMno());
			ps.setString(4, ai.getEmail());
			ps.setFloat(5, ai.getAggregate());
			ps.setString(6, ai.getStream());
			n = ps.executeUpdate();
			assertEquals(1, n);

		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	@Test
	public void testGetApplicantDetails() {

		c = DBUtil.getConnection();
		try {
			int x = 1001;
			PreparedStatement ps = c.prepareStatement(QueryMapper.SELECT);
			ps.setInt(1, x);

		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

}
