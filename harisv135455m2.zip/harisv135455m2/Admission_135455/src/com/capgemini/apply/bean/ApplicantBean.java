package com.capgemini.apply.bean;

public class ApplicantBean {

	private long applyId;
	private String Fname;
	private String Lname;
	private String email;
	private long mno;
	private String stream;
	private float aggregate;
	public long getApplyId() {
		return applyId;
	}
	public void setApplyId(long applyId) {
		this.applyId = applyId;
	}
	public String getFname() {
		return Fname;
	}
	public void setFname(String fname) {
		Fname = fname;
	}
	public String getLname() {
		return Lname;
	}
	public void setLname(String lname) {
		Lname = lname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getMno() {
		return mno;
	}
	public void setMno(long mno) {
		this.mno = mno;
	}
	public String getStream() {
		return stream;
	}
	public void setStream(String stream) {
		this.stream = stream;
	}
	public float getAggregate() {
		return aggregate;
	}
	public void setAggregate(float aggregate) {
		this.aggregate = aggregate;
	}
	
	
}
