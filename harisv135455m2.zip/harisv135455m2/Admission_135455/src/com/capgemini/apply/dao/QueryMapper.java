package com.capgemini.apply.dao;

public interface QueryMapper {
	
	public static final String INSERT = "INSERT INTO Candidate_detail values(apply_id_seq.nextval,?,?,?,?,?,?)";
	public static final String SELECT = "SELECT * FROM Candidate_detail where applyId = ?";
	public static final String SELECTQ ="SELECT apply_id_seq.currval from dual";

}
