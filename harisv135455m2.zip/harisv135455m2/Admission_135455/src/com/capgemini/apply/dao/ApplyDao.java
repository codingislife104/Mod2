package com.capgemini.apply.dao;

import com.capgemini.apply.bean.ApplicantBean;
import com.capgemini.contact.exception.ApplicantException;

public interface ApplyDao {

	public int addApplicantDetails(ApplicantBean applicant) throws ApplicantException;
	public ApplicantBean getApplicantDetails(long applicantID) throws ApplicantException;
	
}
