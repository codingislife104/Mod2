package com.capgemini.apply.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.apply.bean.ApplicantBean;
import com.capgemini.contact.exception.ApplicantException;

public class ApplyDaoImpl implements ApplyDao {

	Logger log = Logger.getRootLogger();
	
	private Connection c;
	
	private int n;

	private ResultSet rs;

	private ApplicantBean ab1 = new ApplicantBean();

	@Override
	public int addApplicantDetails(ApplicantBean applicant)
			throws ApplicantException {

		try {
			c = DBUtil.getConnection();
			System.out.println("connection");

			PreparedStatement ps = c.prepareStatement(QueryMapper.INSERT);

			System.out.println("FirstName " + applicant.getFname());
			System.out.println("LastName " + applicant.getLname());
			System.out.println("Contact number " + applicant.getMno());
			System.out.println("Email " + applicant.getEmail());
			System.out.println("Aggregate " + applicant.getAggregate());
			System.out.println("Stream " + applicant.getStream());

			ps.setString(1, applicant.getFname());
			ps.setString(2, applicant.getLname());
			ps.setLong(3, applicant.getMno());
			ps.setString(4, applicant.getEmail());
			ps.setFloat(5, applicant.getAggregate());
			ps.setString(6, applicant.getStream());
			n= ps.executeUpdate();

			PreparedStatement ps1 = c.prepareStatement(QueryMapper.SELECTQ);
			rs = ps1.executeQuery();
			log.info("data added");

			while (rs.next()) {

				System.out.println("Thank you " + applicant.getFname() + " "
						+ " your Unique Id is " + rs.getInt(1)
						+ " Thank you for applying");
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("Problem in adding data");
		} finally {

			try {
				c.close();
				log.info("Connection closed");
			} catch (SQLException ab1) {
				// TODO Auto-generated catch block
				ab1.printStackTrace();
				log.error("Connection not closed");
			}
		}

		return n;
	}

	@Override
	public ApplicantBean getApplicantDetails(long applicantID)
			throws ApplicantException {
		try {
			
			c = DBUtil.getConnection();
			PreparedStatement ps = null;
			ps = c.prepareStatement(QueryMapper.SELECT);
			ps.setLong(1, applicantID);
			rs = ps.executeQuery();
					
			
			while (rs.next()) {
				ab1.setApplyId(rs.getInt(1));
				ab1.setFname(rs.getString(2));
				ab1.setLname(rs.getString(3));
				ab1.setMno(rs.getLong(4));
				ab1.setEmail(rs.getString(5));
				ab1.setStream(rs.getString(7));
				ab1.setAggregate(rs.getFloat(6));
				

			}
			log.info("data retrieved");
			return ab1;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

		
	}

}
