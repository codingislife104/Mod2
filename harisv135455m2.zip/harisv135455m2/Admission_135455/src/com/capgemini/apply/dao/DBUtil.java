package com.capgemini.apply.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;

public class DBUtil {

	
	static Logger log = Logger.getLogger("DB Util Class");

	private static FileInputStream fis;
	
	public static Connection c;

	
	@SuppressWarnings("unused")
	public static Connection getConnection() {
		try {
			fis = new FileInputStream("resources/jdbc.properties");
			log.info("File opened");

			Properties p = new Properties();

			p.load(fis);

		
			String url = p.getProperty("url");
		
			String uname = p.getProperty("uname");
			
			String pwd = p.getProperty("pwd");

			c = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg1125","training1125");
			log.info("Connection created");

		} catch (IOException e) {
			log.error("IO exception" + e);

		} catch (SQLException e) {
			log.error("SQL exception" + e);
			e.printStackTrace();
		} finally {
			try {
				fis.close();
				log.info("File Closed");
			} catch (IOException e) {
				log.error("Unable to close file");
				e.printStackTrace();
			}
		}
		return c;
	}
}
