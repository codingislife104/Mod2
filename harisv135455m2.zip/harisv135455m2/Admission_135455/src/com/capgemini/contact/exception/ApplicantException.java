package com.capgemini.contact.exception;

public class ApplicantException extends Exception {

	private static final long serialVersionUID = -1049364966170471769L;

}
