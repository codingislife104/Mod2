package com.capgemini.contact.ui;

import java.util.Scanner;

import com.capgemini.apply.bean.ApplicantBean;
import com.capgemini.contact.exception.ApplicantException;
import com.capgemini.contact.service.ApplyServiceImpl;

public class Client {

	private static Scanner sc;
	public static ApplicantBean ab;
	static ApplicantBean ab1;
	static ApplyServiceImpl asi = new ApplyServiceImpl();

	public static void main(String[] args) throws ApplicantException{

		sc = new Scanner(System.in);
		ab = new ApplicantBean();

		System.out
				.println("****************Admission Management System****************");
		System.out.println("Select an operation:");
		System.out.println("1.Enter Details");
		System.out.println("2.View Details based on Applicant Id");
		System.out.println("0.Exit");
		System.out
				.println("***************************************************");
		System.out.println("Please Enter a choice:");

		int choice = sc.nextInt();
		
		switch (choice) {
		case 1:
			System.out.println("Enter FirstName:");
			ab.setFname(sc.next());
			System.out.println("Enter LastName:");
			ab.setLname(sc.next());
			System.out.println("Enter Contact Number:");
			ab.setMno(sc.nextLong());
			System.out.println("Enter Email:");
			ab.setEmail(sc.next());
			System.out.println("Enter Aggregate:");
			ab.setAggregate(sc.nextFloat());
			System.out.println("Enter Stream:");
			ab. setStream(sc.next());
		
			int addRes = asi.addApplicantDetails(ab);
			System.out.println(addRes + " Row Inserted");
			break;
			
		case 2:
			System.out.println("Enter Applicant ID");
			ab.setApplyId(sc.nextInt());
			try {
				ab1 = asi.getApplicantDetails(ab.getApplyId());

				System.out.println("Id    " + "First Name   "
						+ "Last Name   " + "ContactNo.   "
						+ "Email    "+ "Aggregate    " + "Stream    ");
				
				
				System.out.println(ab1.getApplyId()+"   "+ ab1.getFname() + "     "+ ab1.getLname()+"   "+ ab1.getMno()+"   "+ ab1.getEmail() + "   "+ ab1.getAggregate()+ "      " + ab1.getStream());

			} catch (ApplicantException e) {
				e.printStackTrace();
			}
			break;
		case 0:
			System.out.println("Thank you for applying!!");
			break;
		default:
			System.out.println("Not a Valid Input");
			break;
		}

	}

}
