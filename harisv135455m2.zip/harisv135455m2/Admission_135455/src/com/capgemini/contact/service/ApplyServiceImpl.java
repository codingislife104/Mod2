package com.capgemini.contact.service;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.apply.bean.ApplicantBean;
import com.capgemini.apply.dao.ApplyDaoImpl;
import com.capgemini.contact.exception.ApplicantException;
import com.capgemini.contact.ui.Client;

public class ApplyServiceImpl implements ApplyService {

	ApplyDaoImpl adi = new ApplyDaoImpl();

	Scanner sc = new Scanner(System.in);
	int save = 0;

	@Override
	public int addApplicantDetails(ApplicantBean apply)
			throws ApplicantException {
		if (isValidApplicant(apply)) {
			return adi.addApplicantDetails(apply);
		}
		return 0;
	}

	@Override
	public ApplicantBean getApplicantDetails(long applicantID)
			throws ApplicantException {
		return adi.getApplicantDetails(applicantID);
	}

	@Override
	public boolean isValidApplicant(ApplicantBean applicant)
			throws ApplicantException {
		if (validateFName(applicant.getFname())) {

			if (validateLName(applicant.getLname())) {

				if (validateEmail(applicant.getEmail())) {

					if (validateContactNo(applicant.getMno())) {

						if (validateStream(applicant.getStream())) {

							
								System.out.println("Entered");
								return true;

							
						}
					}
				}
			}
		}
		return false;
	}


	


	private boolean validateFName(String fname) {
		Pattern pattern = Pattern.compile("[A-Z][a-z]{2,}");
		Matcher matcher = pattern.matcher(fname);
		if (matcher.matches()) {
			System.out.println("FirstName Valid");

			// log.info("Name validation done");
		} else {
			System.out.println("Not a Valid FirstName");
			System.out.println("Enter a Valid FirstName:");
			fname = sc.next();
			Client.ab.setFname(fname);
			validateFName(fname);
		}
		return true;
		
	}
	

	
	private boolean validateLName(String lname) {
		Pattern pattern = Pattern.compile("[A-Z][a-z]{2,}");
		Matcher matcher = pattern.matcher(lname);
		if (matcher.matches()) {
			System.out.println("LastName Valid");

			// log.info("Name validation done");
		} else {
			System.out.println("Not a Valid FirstName");
			System.out.println("Enter a Valid FirstName:");
			lname = sc.next();
			Client.ab.setFname(lname);
			validateLName(lname);
		}
		return true;
	}
	
	
	


	
	
	
	
	private boolean validateEmail(String email) {
		Pattern pattern = Pattern
				.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
						+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
		Matcher matcher = pattern.matcher(email);
		if (matcher.matches()) {
			System.out.println("Email Valid");
		} else {
			System.out.println("Not a Valid Email");
			System.out.println("Enter a Valid Email:");
			email = sc.next();
			Client.ab.setFname(email);
			validateEmail(email);
		}
		return true;

	}

	
	
	
	
	
	public boolean validateContactNo(Long Mno) {
		Pattern pattern = Pattern.compile("[789][0-9]{9}");
		Matcher matcher = pattern.matcher(Long.toString(Mno));
		if (matcher.matches()) {
			System.out.println("Number valid");
			// log.info("number validation done");
		} else {
			System.out.println("Not a Valid contact number");
			System.out.println("Enter a Valid contact number:");
			Mno = sc.nextLong();
			Client.ab.setMno(Mno);
			validateContactNo(Mno);
		}

		return true;

	}

	

	
	public boolean validateStream(String Stream) {
		
		String userInput = sc.next().toLowerCase();

	if(userInput.equals("ComputerScience"))	{
		
		//Stream.toLowerCase().equals("it"))
		
		System.out.println("Stream is valid");
		
	}
	
	else if(userInput.equals("InformationTechnology")){
		
		System.out.println("Stream is valid");
	}
	else if (Stream.equals(null))
	{
		System.out.println("Stream is not valid");
		System.out.println("Enter valid Stream");
		Stream=sc.next();
		Client.ab.setStream(Stream);
		validateStream(Stream);
	}	
	return true;

	}
}
