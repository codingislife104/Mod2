package com.capgemini.contact.service;

import com.capgemini.apply.bean.ApplicantBean;
import com.capgemini.contact.exception.ApplicantException;

public interface ApplyService {

	public int addApplicantDetails(ApplicantBean apply)
			throws ApplicantException;

	public ApplicantBean getApplicantDetails(long applicantID)
			throws ApplicantException;

	public boolean isValidApplicant(ApplicantBean applicant)
			throws ApplicantException;

}
